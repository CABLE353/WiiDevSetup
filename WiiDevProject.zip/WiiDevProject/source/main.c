
#include "../include/main.h"


int main()
{
    GRRLIB_Init();

    while(1)
    {


    }
    return 0;
}
