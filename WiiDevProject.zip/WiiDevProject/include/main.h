#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <grrlib.h>
#include <wiiuse/wpad.h>
#include <string.h>


#endif // MAIN_H_INCLUDED
