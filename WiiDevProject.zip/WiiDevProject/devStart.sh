pacman --sync --needed --noconfirm libfat-ogc ppc-libpng ppc-freetype ppc-libjpeg-turbo
cd C:/
cd GRRLIB
cd GRRLIB
Make